<div>
    <ul class="uk-breadcrumb">
        <li class="uk-active"><span>@lang('Assets')</span></li>
    </ul>
</div>

<div riot-view>
    <cp-assets></cp-assets>
</div>
